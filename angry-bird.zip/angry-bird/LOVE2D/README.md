# angry-bird/love2d
Source code adapted from https://github.com/games50/angrybirds - with the
following additional features:

- When the player presses spacebar, the flying alien (that has not collided
  with anything yet) splits into three
